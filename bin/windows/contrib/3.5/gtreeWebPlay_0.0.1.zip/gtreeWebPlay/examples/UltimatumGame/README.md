This is a simple example app for an Ultimatum Game.

Look at `global.R` for the code with detailed comments.

In the pages folder you find slightly customized pages.