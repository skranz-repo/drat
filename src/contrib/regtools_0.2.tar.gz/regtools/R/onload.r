.onLoad <- function(...) {
   options(list(showreg.package = c("texreg","stargazer")))
   #cat("Package loaded:")
   #print(options("showreg.package")[1])
   #getOption("showreg.package")
} 