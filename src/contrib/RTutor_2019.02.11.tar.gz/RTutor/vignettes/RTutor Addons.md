---
title: RTutor Addons
author: Sebastian Kranz, Ulm University
date: 'Version from 2015-11-03'
output:
  pdf_document:
    toc: yes
    number_sections: yes    
---

# Addons

The long term plan is that RTutor can be extended by different addons. So far we only have the "quiz" addon, which is part of the RTutor package.


# Quiz

See the file 'QuizExample_sol.Rmd' in the examples section for an example for how to include quizes. There is no better description for the quiz addon so far. But hopefully the structure is self explanatory.
