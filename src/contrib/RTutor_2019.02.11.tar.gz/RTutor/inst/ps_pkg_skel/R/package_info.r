ps.pkg.info = function() {
  # Name of this package
  package = "PACKAGE_NAME"
  
  # Name of problem sets in the package
  ps = c("PROBLEM_SET_NAME")
  
  list(package=package, ps = ps)
}
