ps.pkg.info = function() {
  # Name of this package
  package = "RTutorECars"
  
  # Name of problem sets in the package
  ps = c("ECars")
  
  list(package=package, ps = ps)
}
