rampl
=======

Tools to run AMPL models from R

## Installation

First install the package devtools from CRAN and then run

```{r}
  library(devtools);
  install_github("skranz/rgmpl")
  install_github("skranz/rampl")
  
  install.packages("XMLRPC", repos = "http://www.omegahat.org/R", type = "source")
  install.packages("rneos")
```



