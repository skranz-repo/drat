Tools for presenting regressions results

Installation:

```r
if (!require(devtools)) install.packages("devtools")
devtools::install_github("skranz/restorepoint")
devtools::install_github("skranz/regtools")
```
