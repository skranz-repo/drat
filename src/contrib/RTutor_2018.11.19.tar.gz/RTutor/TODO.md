# To do

- Set window vertical position to top when pressing next button
- Try to speed up start up.

# Done
- Allow chunk hints that are not associated with an expression
  - We can now have one hint at the beginning of the chunk that
    is not associated to any expression.