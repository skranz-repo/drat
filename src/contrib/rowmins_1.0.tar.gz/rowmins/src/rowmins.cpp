#include <Rcpp.h>

using namespace Rcpp ;

// [[Rcpp::export()]]
IntegerVector C_which_ColMins(NumericMatrix X) {
  int n = X.ncol();
  IntegerVector V(n);
  for (int i=0; i<n; i++) {
     NumericVector W = X.column(i);
     // from the STL
     V[i] = std::distance(W.begin(),std::min_element(W.begin(), W.end())) +1;  
  }
  return(V);

}


RcppExport SEXP C_which_rowMins(SEXP mat) {
  BEGIN_RCPP
  Rcpp::NumericMatrix X(mat);
  int n = X.nrow();
	Rcpp::IntegerVector V(n);
	for (int i=0; i<n; i++) {
  	Rcpp::NumericVector W = X.row(i);
  	V[i] = std::distance(W.begin(),std::min_element(W.begin(), W.end())) +1;  // from the STL
	}
	return(V);
  
  END_RCPP
}

RcppExport SEXP C_colMins(SEXP mat) {
  BEGIN_RCPP
  Rcpp::NumericMatrix X(mat);
  int n = X.ncol();
  Rcpp::NumericVector V(n);
  for (int i=0; i<n; i++) {
    Rcpp::NumericVector W = X.column(i);
    V[i] = *std::min_element(W.begin(), W.end());  // from the STL
  }
  return(V);
  END_RCPP
}
RcppExport SEXP C_rowMins(SEXP mat) {
  BEGIN_RCPP
  Rcpp::NumericMatrix X(mat);
  int n = X.nrow();
  Rcpp::NumericVector V(n);
  for (int i=0; i<n; i++) {
     Rcpp::NumericVector W = X.row(i);
     V[i] = *std::min_element(W.begin(), W.end());  // from the STL
  }
  return(V);  
  END_RCPP
}

RcppExport SEXP C_which_colMaxs(SEXP mat) {
  BEGIN_RCPP
  Rcpp::NumericMatrix X(mat);
  int n = X.ncol();
	Rcpp::IntegerVector V(n);
	for (int i=0; i<n; i++) {
  	Rcpp::NumericVector W = X.column(i);
  	V[i] = std::distance(W.begin(),std::max_element(W.begin(), W.end())) +1;  // from the STL
	}
	return(V);
  
  END_RCPP
}

RcppExport SEXP C_which_rowMaxs(SEXP mat) {
  BEGIN_RCPP
    Rcpp::NumericMatrix X(mat);
  int n = X.nrow();
	Rcpp::IntegerVector V(n);
	for (int i=0; i<n; i++) {
  	Rcpp::NumericVector W = X.row(i);
  	V[i] = std::distance(W.begin(),std::max_element(W.begin(), W.end())) +1;  // from the STL
	}
	return(V);
  END_RCPP
}

RcppExport SEXP C_colMaxs(SEXP mat) {
  BEGIN_RCPP
    Rcpp::NumericMatrix X(mat);
  int n = X.ncol();
	Rcpp::NumericVector V(n);
	for (int i=0; i<n; i++) {
  	Rcpp::NumericVector W = X.column(i);
  	V[i] = *std::max_element(W.begin(), W.end());  // from the STL
	}
	return(V);
  
  END_RCPP
}
RcppExport SEXP C_rowMaxs(SEXP mat) {
  BEGIN_RCPP
    Rcpp::NumericMatrix X(mat);
  int n = X.nrow();
	Rcpp::NumericVector V(n);
	for (int i=0; i<n; i++) {
  	Rcpp::NumericVector W = X.row(i);
  	V[i] = *std::max_element(W.begin(), W.end());  // from the STL
	}
	return(V);
  
  END_RCPP
}
