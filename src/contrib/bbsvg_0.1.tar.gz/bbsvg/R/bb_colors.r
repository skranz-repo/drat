
colors_bb_series = function(n=11) {
  c(blue1="#0C5BB0",red="#EE0011",green2="#15983D", purple="#800080",
    orange="#FA6B09",brown= "#9A703E",blue2="#149BED",   turquoise ="#16A08C",
    pink="#EC579A",  yellow="#FEC10B" ,green="#A1C720")[1:n]    
}