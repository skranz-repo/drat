 C_which_colMins <- function (mat) 
.Call("C_which_colMins", mat, PACKAGE = "skUtils")

 C_which_rowMins <- function (mat) 
.Call("C_which_rowMins", mat, PACKAGE = "skUtils")

 C_colMins <- function (mat) 
.Call("C_colMins", mat, PACKAGE = "skUtils")

 C_rowMins <- function (mat) 
.Call("C_rowMins", mat, PACKAGE = "skUtils")

 C_which_colMaxs <- function (mat) 
.Call("C_which_colMaxs", mat, PACKAGE = "skUtils")

 C_which_rowMaxs <- function (mat) 
.Call("C_which_rowMaxs", mat, PACKAGE = "skUtils")

 C_colMaxs <- function (mat) 
.Call("C_colMaxs", mat, PACKAGE = "skUtils")

 C_rowMaxs <- function (mat) 
.Call("C_rowMaxs", mat, PACKAGE = "skUtils")

