# Make sure that data.table awareness works!

#.onLoad = function(...)  {
#  assignInNamespace("cedta.override", union(data.table:::cedta.override,"dplyrExtras"), "data.table")
#}
