News for dplyrExtras
=====================

2016-07-07: Bugfix (due to new dplyr version), extension of functionality and better documentation for xsummarise_each 

2016-06-28: Rename `mutate_if` to `mutate_rows`, since dplyr 5.0 introduced an own `mutate_if` function with quite different behavior. The original `mutate_if` still exists in dplyrExtras for backward compatibility, but using `mutate_rows` is preferred.
