examples.bargaining = function() {

  # Agent
  e = 5
  c_eff = 0.5
  c_pun1 = 0.1
  c_pun2 = 0.3
  pun1 = 1
  pun2 = 3
  
  g1 = matrix(byrow=TRUE, ncol=2, c(
    -c_pun1*pun1-pun2, -c_pun1*pun1,
    0-pun2, 0,
    -c_eff*e-pun2, -c_eff*e
  ))
  g2 = matrix(byrow=TRUE, ncol=2, c(
    -pun1-c_pun2*pun2, -pun1,
    0-c_pun2*pun2, 0,
    e-c_pun2*pun2, e
  ))
  rownames(g1) = rownames(g2) = c("p1","n1","e1")
  colnames(g1) = colnames(g2) = c("p2","n2")
  
  
  # Load package
  library(repgame)
  # Initialize the model of the repeated game
  m = init.game(g1=g1,g2=g2, name="Principal-Agent",symmetric=FALSE)
# Solve the model 
  m = solve.game(m, keep.only.opt.rows=!TRUE)
  m$opt.mat
  
  delta.seq = seq(0,0.6, by = 0.01)
  find.bargaining.payoff(m, delta.seq, add.d = TRUE)  
    
}

get.opt.of.delta = function(m, delta) {
  restore.point("get.opt.of.delta")
  
  mat = get.mat.of.delta(m, delta)
  res = as.list(mat)
  names(res) = colnames(mat)
  res$delta = delta
  return(res)
  
  opt.mat = m$opt.mat
  ord = order[m$opt.mat,delta]
  dupl = duplicated(m$opt.mat[,"delta"],fromLast = TRUE)
  opt.mat = opt.mat[!dupl, ,drop=FALSE]
  
  row = findInterval(delta, opt.mat[,"delta"], rightmost.closed = TRUE)
  res = as.list(opt.mat[row,])
}

find.bargaining.payoff = function(m, delta, beta=rep(1/m$n, m$n), add.d=FALSE) {
  restore.point("find.bargaining.payoff")
  if (length(delta)>1) {
    res = lapply(delta, function(del) {
      find.bargaining.payoff(m, del, beta, add.d=add.d)
    })
    res = do.call(rbind, res)
    return(cbind(data.frame(delta=delta), res))
  }
  
  d = find.disagreement.payoff(m, delta, beta)
  
  opt.eq = get.opt.of.delta(m, delta)
  U = opt.eq$Ue
  
  b = d + beta * (U - sum(d))
  names(b) = paste0("b", 1:m$n)
  if (add.d) {
    names(d) = paste0("d", 1:m$n)
    return(c(b,d))
  }
  b
}

find.disagreement.payoff = function(m, delta=0.5, beta=rep(1/m$n, m$n)) {
  restore.point("find.disagreement.action")
  
  gd1 = (1-delta*beta[1])*m$g1 - (delta*beta[2]) * m$g2
  gd2 = (1-delta*beta[2])*m$g2 - (delta*beta[2]) * m$g1
  
  nr = NROW(gd1); nc = NCOL(gd1)
  
  gbr1 = matrix(colMaxs(gd1), nr, nc, byrow=TRUE)
  is.br1 = gd1 == gbr1 
  
  gbr2 = matrix(rowMaxs(gd2), nr, nc, byrow=FALSE)
  is.br2 = gd2 == gbr2 

  is.nash = is.br1 & is.br2
  
  ind = which(is.nash)[1]
  
  d = c(m$g1[ind], m$g2[ind])
  d  
}
