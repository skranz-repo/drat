# Relational Contracts

See the `vignettes`, the documents in `docs` and the examples in `inst/examples`

## Installation

```r
install.packages("RelationalContracts",repos = c("https://skranz-repo.github.io/drat/",getOption("repos")))
```
