ps.pkg.info = function() {
  # Name of this package
  package = "RTutorIncentiveContracts"
  
  # Name of problem sets in the package
  ps = c("IncentiveContracts")
  
  list(package=package, ps = ps)
}
